package com.jisnex.live

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.decoder.AudioDecoderInterface
import com.pedro.encoder.input.decoder.VideoDecoderInterface
import com.pedro.library.rtmp.RtmpDisplay
import com.pedro.library.rtmp.RtmpFromFile

class StreamService : Service(), ConnectChecker, VideoDecoderInterface, AudioDecoderInterface {

    companion object {
        const val ACTION_START = "jisnex.start"
        const val ACTION_STOP = "jisnex.stop"
        @Volatile var running = false
        @Volatile var startedAt = 0L
        @Volatile var status = "বন্ধ"
        @Volatile var title = ""
        @Volatile var broadcastId = ""
    }

    private val handler = Handler(Looper.getMainLooper())
    private var display: RtmpDisplay? = null
    private var file: RtmpFromFile? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var ytBid = ""
    private var ytCh = ""
    @Volatile private var ytWatch = false
    private val autoStop = Runnable { setStatus("সময় শেষ, স্ট্রিম বন্ধ"); stopAll() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.init(applicationContext)
        if (intent?.action == ACTION_STOP) { stopAll(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START && !running) startStreaming(intent)
        return START_NOT_STICKY
    }

    private fun startStreaming(i: Intent) {
        val mode = i.getStringExtra("mode") ?: "screen"
        val url = i.getStringExtra("url") ?: return
        val audio = i.getStringExtra("audio") ?: "internal"
        title = i.getStringExtra("title") ?: ""
        val minutes = i.getIntExtra("minutes", 0)
        ytBid = i.getStringExtra("bid") ?: ""
        ytCh = i.getStringExtra("chid") ?: ""
        broadcastId = ytBid

        var type = 0
        if (Build.VERSION.SDK_INT >= 29) {
            type = if (mode == "screen") {
                var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                t
            } else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, notif("স্ট্রিম শুরু হচ্ছে…"), type)
            else startForeground(1, notif("স্ট্রিম শুরু হচ্ছে…"))
        } catch (e: Exception) {
            setStatus("সার্ভিস শুরু ব্যর্থ: ${e.message}"); endYt(); stopSelf(); return
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jisnex:stream").apply { acquire() }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "jisnex:wifi").apply { acquire() }

        var ok: Boolean
        try {
            ok = if (mode == "screen") startScreen(i, url, audio) else startFile(i, url)
        } catch (e: Throwable) {
            setStatus("ত্রুটি: ${e.message}"); ok = false
        }
        if (!ok) { if (status == "বন্ধ" || status.startsWith("স্ট্রিম শুরু")) setStatus("প্রস্তুতি ব্যর্থ (ডিভাইস সাপোর্ট করছে না)"); stopAll(); return }

        running = true
        startedAt = System.currentTimeMillis()
        setStatus("কানেক্ট হচ্ছে…")
        if (minutes > 0) handler.postDelayed(autoStop, minutes * 60_000L)
    }

    private fun startScreen(i: Intent, url: String, audio: String): Boolean {
        val w = i.getIntExtra("w", 1280); val h = i.getIntExtra("h", 720)
        val fps = i.getIntExtra("fps", 30); val kbps = i.getIntExtra("kbps", 2500)
        val code = i.getIntExtra("resultCode", 0)
        val data = i.getParcelableExtra<Intent>("data") ?: return false
        val d = RtmpDisplay(this, true, this)
        d.setIntentResult(code, data)
        val aOk = when (audio) {
            "internal" -> if (Build.VERSION.SDK_INT >= 29) d.prepareInternalAudio(128 * 1000, 44100, true, false, false)
                          else d.prepareAudio(128 * 1000, 44100, true, false, false)
            "mic" -> d.prepareAudio(128 * 1000, 44100, true, true, true)
            else -> { val r = d.prepareAudio(128 * 1000, 44100, true, false, false); d.disableAudio(); r }
        }
        val vOk = d.prepareVideo(w, h, fps, kbps * 1000, 0, resources.displayMetrics.densityDpi)
        display = d
        if (!aOk || !vOk) return false
        d.startStream(url)
        return true
    }

    private fun startFile(i: Intent, url: String): Boolean {
        val path = i.getStringExtra("file") ?: return false
        val kbps = i.getIntExtra("kbps", 2500)
        val f = RtmpFromFile(this, this, this)
        file = f
        val vOk = f.prepareVideo(path, kbps * 1000)
        val aOk = f.prepareAudio(path, 128 * 1000)
        if (!vOk) return false
        if (!aOk) { setStatus("ভিডিওতে অডিও নেই বা পড়া যায়নি") }
        f.startStream(url)
        return true
    }

    private fun stopAll() {
        handler.removeCallbacksAndMessages(null)
        endYt()
        try { display?.let { if (it.isStreaming) it.stopStream() } } catch (_: Throwable) {}
        try { file?.let { if (it.isStreaming) it.stopStream() } } catch (_: Throwable) {}
        display = null; file = null
        try { wake?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        try { wifi?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        running = false
        if (!status.startsWith("সময়") && !status.startsWith("ত্রুটি") && !status.startsWith("সংযোগ")) status = "বন্ধ"
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { if (running) stopAll(); super.onDestroy() }

    private fun setStatus(s: String) {
        status = s
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1, notif(s))
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel("live", "Live Stream", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, StreamService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, "live")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("JISNEX Live" + if (title.isNotEmpty()) " • $title" else "")
            .setContentText(text).setOngoing(true).setContentIntent(open)
            .addAction(0, "স্ট্রিম বন্ধ করুন", stop).build()
    }

    // ---- YouTube broadcast ----
    /** স্ট্রিম ডেটা পৌঁছালে broadcast কে নিশ্চিতভাবে LIVE এ নেয়। */
    private fun watchYt() {
        val b = ytBid; val c = ytCh
        if (b.isEmpty() || ytWatch) return
        ytWatch = true
        Thread {
            var n = 0
            while (ytWatch && n < 60) {
                try {
                    val acc = Yt.byId(c) ?: break
                    val st = Yt.lifecycle(acc, b)
                    if (st == "live" || st == "liveStarting") {
                        handler.post { if (running) setStatus("🔴 YouTube LIVE চলছে") }
                        break
                    }
                    if (st == "complete" || st == "revoked") break
                    if (st == "ready" || st == "testing") {
                        try { Yt.transition(acc, b, "live") } catch (_: Throwable) { }
                    }
                } catch (_: Throwable) { }
                n++
                try { Thread.sleep(4000) } catch (_: Throwable) { }
            }
            ytWatch = false
        }.start()
    }

    /** স্ট্রিম বন্ধ হলে YouTube এ লাইভ শেষ করে। */
    private fun endYt() {
        val b = ytBid; val c = ytCh
        ytBid = ""; ytCh = ""; broadcastId = ""; ytWatch = false
        if (b.isEmpty()) return
        Thread {
            try { Yt.byId(c)?.let { Yt.finish(it, b) } } catch (_: Throwable) { }
        }.start()
    }

    // ---- ConnectChecker ----
    override fun onConnectionStarted(url: String) { }
    override fun onConnectionSuccess() { setStatus("🔴 LIVE চলছে"); watchYt() }
    override fun onConnectionFailed(reason: String) {
        handler.post {
            val retry = try { display?.reTry(5000, reason) ?: file?.reTry(5000, reason) ?: false } catch (e: Throwable) { false }
            if (retry) setStatus("সংযোগ নেই, আবার চেষ্টা চলছে…")
            else { setStatus("সংযোগ ব্যর্থ: $reason"); stopAll() }
        }
    }
    override fun onNewBitrate(bitrate: Long) { }
    override fun onDisconnect() { }
    override fun onAuthError() { handler.post { setStatus("সংযোগ ব্যর্থ: Auth error"); stopAll() } }
    override fun onAuthSuccess() { }

    // ---- file loop ----
    override fun onVideoDecoderFinished() { handler.post { try { file?.reSyncFile() } catch (_: Throwable) {} } }
    override fun onAudioDecoderFinished() { }
}
