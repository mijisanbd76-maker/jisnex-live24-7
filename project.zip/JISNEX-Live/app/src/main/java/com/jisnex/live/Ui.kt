package com.jisnex.live

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat

object C {
    val BG = Color.parseColor("#0A0E1A")
    val CARD = Color.parseColor("#151B2E")
    val RED = Color.parseColor("#FF1F2D")
    val BLUE = Color.parseColor("#2D7BFF")
    val TEXT = Color.WHITE
    val SUB = Color.parseColor("#9AA3B8")
    val GREEN = Color.parseColor("#22C55E")
}

object Store {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("jisnex", Context.MODE_PRIVATE) }
    fun s(k: String, d: String = "") = sp.getString(k, d) ?: d
    fun put(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun i(k: String, d: Int = 0) = sp.getInt(k, d)
    fun put(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    fun b(k: String, d: Boolean = false) = sp.getBoolean(k, d)
    fun put(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    // ---- login accounts ----
    fun adminId() = s("admin_id", "admin")
    fun adminPass() = s("admin_pass", "admin123")
    fun users(): MutableList<Pair<String, String>> =
        s("users").split("\n").filter { it.contains("\t") }.map {
            val p = it.split("\t"); Pair(p[0], p[1])
        }.toMutableList()
    fun saveUsers(l: List<Pair<String, String>>) = put("users", l.joinToString("\n") { it.first + "\t" + it.second })
    fun check(id: String, pass: String): Boolean {
        if (id == adminId() && pass == adminPass()) return true
        return users().any { it.first == id && it.second == pass }
    }
    fun isAdmin() = s("current_user") == adminId()
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.round(color: Int, r: Int = 14) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat()
}

fun Context.label(t: String, size: Float = 14f, color: Int = C.TEXT, bold: Boolean = false) =
    TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(14), dp(14), dp(14), dp(14))
    background = round(C.CARD, 16)
    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { setMargins(0, 0, 0, dp(10)) }
}

fun Context.button(text: String, color: Int = C.RED, onClick: () -> Unit) = Button(this).apply {
    this.text = text; isAllCaps = false; setTextColor(Color.WHITE); textSize = 15f
    background = round(color, 12)
    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
        .apply { setMargins(0, dp(6), 0, dp(6)) }
    setOnClickListener { onClick() }
}

fun Context.edit(hint: String, value: String = "", pwd: Boolean = false, number: Boolean = false, multi: Boolean = false) =
    EditText(this).apply {
        this.hint = hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(C.SUB)
        background = round(Color.parseColor("#0F1424"), 10)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        inputType = when {
            pwd -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            number -> InputType.TYPE_CLASS_NUMBER
            multi -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            else -> InputType.TYPE_CLASS_TEXT
        }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(0, dp(4), 0, dp(8)) }
    }

fun Context.choice(title: String, options: List<String>, cur: Int, onPick: (Int) -> Unit): Button {
    val b = Button(this)
    fun refresh(i: Int) { b.text = "$title:  ${options[i]}  ▾" }
    refresh(cur.coerceIn(0, options.size - 1))
    b.isAllCaps = false; b.setTextColor(Color.WHITE); b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
    b.background = round(Color.parseColor("#1F2742"), 10)
    b.setPadding(dp(14), 0, dp(14), 0)
    b.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        .apply { setMargins(0, dp(4), 0, dp(4)) }
    b.setOnClickListener {
        AlertDialog.Builder(this).setTitle(title)
            .setItems(options.toTypedArray()) { _, i -> refresh(i); onPick(i) }.show()
    }
    return b
}

fun Context.toggle(text: String, on: Boolean, onChange: (Boolean) -> Unit) = SwitchCompat(this).apply {
    this.text = text; isChecked = on; setTextColor(Color.WHITE); textSize = 14f
    setPadding(0, dp(8), 0, dp(8))
    setOnCheckedChangeListener { _, v -> onChange(v) }
}
