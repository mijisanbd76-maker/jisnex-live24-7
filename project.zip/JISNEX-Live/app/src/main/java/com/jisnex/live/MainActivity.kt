package com.jisnex.live

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {

    private lateinit var content: FrameLayout
    private lateinit var tabViews: List<TextView>
    private var tab = 0
    private val ui = Handler(Looper.getMainLooper())
    private var statusView: TextView? = null
    private var afterPerm: (() -> Unit)? = null
    private var pendingGame: String? = null
    private var pendingSource = "screen"
    private var pendingUrl = ""
    private var pendingBid = ""
    private var pendingCh = ""

    private lateinit var permLauncher: ActivityResultLauncher<Array<String>>
    private lateinit var projLauncher: ActivityResultLauncher<Intent>
    private lateinit var pickLauncher: ActivityResultLauncher<Array<String>>

    private val platforms = listOf("YouTube", "Facebook", "Twitch", "Custom RTMP")
    private val bases = listOf("rtmp://a.rtmp.youtube.com/live2", "rtmps://live-api-s.facebook.com:443/rtmp/", "rtmp://live.twitch.tv/app", "")
    private val resNames = listOf("360p", "480p", "720p (HD)", "1080p (Full HD)")
    private val resW = listOf(640, 852, 1280, 1920)
    private val resH = listOf(360, 480, 720, 1080)
    private val resKbps = listOf(800, 1200, 2500, 4500)
    private val fpsList = listOf(24, 30, 60)
    private val hours = listOf(1, 2, 4, 6, 12, 24, 48, 72)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        if (!Store.b("logged_in")) { startActivity(Intent(this, LoginActivity::class.java)); finish(); return }

        permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val next = afterPerm; afterPerm = null; next?.invoke()
        }
        projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val d = r.data
            if (r.resultCode == RESULT_OK && d != null) launchService("screen", r.resultCode, d)
            else { discardPending(); Toast.makeText(this, "স্ক্রিন ক্যাপচারের অনুমতি দেওয়া হয়নি", Toast.LENGTH_LONG).show() }
        }
        pickLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) importVideo(uri) }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val bar = LinearLayout(this).apply { setBackgroundColor(C.CARD); setPadding(0, dp(6), 0, dp(6)) }
        val names = listOf("🏠\nহোম", "📡\nলাইভ", "🎞\nভিডিও", "🎮\nগেম", "⚙\nসেটিংস")
        tabViews = names.mapIndexed { i, n ->
            TextView(this).apply {
                text = n; gravity = Gravity.CENTER; textSize = 12f; setTextColor(C.SUB)
                setPadding(0, dp(6), 0, dp(6))
                setOnClickListener { show(i) }
            }
        }
        tabViews.forEach { bar.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
        root.addView(bar)
        setContentView(root)
        show(0)
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) tickStatus() }
    override fun onPause() { super.onPause(); ui.removeCallbacksAndMessages(null) }

    private fun tickStatus() {
        statusView?.let {
            val live = StreamService.running
            val el = if (live) (System.currentTimeMillis() - StreamService.startedAt) / 1000 else 0
            it.text = (if (live) "🔴 " else "⚪ ") + StreamService.status +
                (if (live) "   %02d:%02d:%02d".format(el / 3600, (el % 3600) / 60, el % 60) else "")
            it.setTextColor(if (live) C.RED else C.SUB)
        }
        ui.postDelayed({ tickStatus() }, 1000)
    }

    private fun show(i: Int) {
        tab = i
        tabViews.forEachIndexed { k, v -> v.setTextColor(if (k == i) C.RED else C.SUB) }
        content.removeAllViews()
        statusView = null
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(24)) }
        when (i) { 0 -> home(col); 1 -> live(col); 2 -> videos(col); 3 -> game(col); else -> settings(col) }
        content.addView(ScrollView(this).apply { addView(col) })
        ui.removeCallbacksAndMessages(null); tickStatus()
    }

    private fun statusCard(col: LinearLayout) {
        val c = card()
        statusView = label("", 16f, C.SUB, true)
        c.addView(statusView)
        col.addView(c)
    }

    // ================= HOME =================
    private fun home(col: LinearLayout) {
        col.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(context).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(dp(64), dp(64)))
            addView(label("  JISNEX Live 24/7", 22f, C.TEXT, true))
        })
        col.addView(label("হ্যালো, ${Store.s("current_user")}", 13f, C.SUB).apply { setPadding(0, dp(8), 0, dp(12)) })
        statusCard(col)
        val q = card()
        q.addView(label("কুইক অ্যাকশন", 16f, C.TEXT, true))
        q.addView(button("📺  YouTube চ্যানেল লগইন", C.RED) { addChannel() })
        q.addView(button("📡  লাইভ শুরু (Start Stream)", C.RED) { show(1) })
        q.addView(button("🎞  ভিডিও আপলোড / ভিডিও দিয়ে লাইভ", C.BLUE) { show(2) })
        q.addView(button("🎮  গেম খেলে লাইভ", 0xFF7C3AED.toInt()) { show(3) })
        q.addView(button("▶  YouTube Studio খুলুন (চ্যানেল লগইন / স্ট্রিম কী)", 0xFF374151.toInt()) { openUrl("https://studio.youtube.com") })
        col.addView(q)
        val h = card()
        h.addView(label("কীভাবে ব্যবহার করবেন", 16f, C.TEXT, true))
        h.addView(label("পদ্ধতি ১ (চ্যানেল লগইন): সেটিংসে Client ID/Secret দিন → 'চ্যানেল লগইন' → লাইভ ট্যাবে টাইটেল দিয়ে Go Live। অ্যাপ নিজেই YouTube এ লাইভ তৈরি ও শুরু করবে।\n\nপদ্ধতি ২ (Stream Key): লাইভ ট্যাবে মোড 'Stream Key' বাছুন → YouTube Studio র Stream key পেস্ট করুন → Go Live।\n\nঅ্যাপ থেকে বের হলেও স্ট্রিম চলবে; বন্ধ করতে আবার অ্যাপে ঢুকে Stop চাপুন।", 13f, C.SUB).apply { setPadding(0, dp(6), 0, 0) })
        col.addView(h)
    }

    // ================= LIVE =================
    private fun live(col: LinearLayout) {
        statusCard(col)
        if (StreamService.running && StreamService.broadcastId.isNotEmpty())
            col.addView(button("▶  YouTube এ লাইভ দেখুন", C.BLUE) { openUrl("https://www.youtube.com/watch?v=" + StreamService.broadcastId) })
        val mode = Store.i("mode", 0)
        val mc = card()
        mc.addView(label("লাইভ করার পদ্ধতি", 16f, C.TEXT, true))
        mc.addView(choice("মোড", listOf("📺 চ্যানেল লগইন (অ্যাপ নিজেই লাইভ বানাবে)", "🔑 Stream Key দিয়ে"), mode) { Store.put("mode", it); show(1) })
        col.addView(mc)
        if (mode == 0) channelCard(col) else keyCard(col)

        val t = card()
        t.addView(label("টাইটেল ও ডেসক্রিপশন", 16f, C.TEXT, true))
        val ti = edit("লাইভ টাইটেল", Store.s("title")); ti.addTextChangedListener(watch { Store.put("title", it) })
        val de = edit("ডেসক্রিপশন", Store.s("desc"), multi = true); de.addTextChangedListener(watch { Store.put("desc", it) })
        t.addView(ti); t.addView(de)
        t.addView(choice("প্রাইভেসি", listOf("Public", "Unlisted", "Private"), Store.i("privacy", 0)) { Store.put("privacy", it) })
        t.addView(label(
            if (mode == 0) "চ্যানেল মোডে টাইটেল, ডেসক্রিপশন ও প্রাইভেসি সরাসরি YouTube লাইভে সেট হবে।"
            else "নোট: Stream Key দিয়ে লাইভ করলে টাইটেল/ডেসক্রিপশন/প্রাইভেসি YouTube Studio তেই সেট হয়।", 11f, C.SUB))
        col.addView(t)

        val s = card()
        s.addView(label("সোর্স ও কোয়ালিটি", 16f, C.TEXT, true))
        s.addView(choice("সোর্স", listOf("স্ক্রিন / গেম", "আপলোড করা ভিডিও (লুপ)"), Store.i("source", 0)) { Store.put("source", it) })
        s.addView(choice("ফরম্যাট", listOf("16:9 লং (ল্যান্ডস্কেপ)", "9:16 শর্ট (পোর্ট্রেট)"), Store.i("orient", 0)) { Store.put("orient", it) })
        s.addView(choice("রেজোলিউশন", resNames, Store.i("res", 2)) { Store.put("res", it) })
        s.addView(choice("FPS", fpsList.map { "$it fps" }, Store.i("fps", 1)) { Store.put("fps", it) })
        s.addView(choice("অডিও", listOf("ফোনের সাউন্ড (গেম/ইন্টারনাল)", "মাইক্রোফোন (মুখে কথা)", "অডিও ছাড়া"), Store.i("audio", 0)) { Store.put("audio", it) })
        s.addView(label("ভিডিও সোর্সে ফরম্যাট/কোয়ালিটি ভিডিওর নিজস্ব সাইজ অনুযায়ী হয়; ইন্টারনাল অডিও Android 10+ এ চলে।", 11f, C.SUB))
        col.addView(s)

        val d = card()
        d.addView(label("সময়সীমা", 16f, C.TEXT, true))
        val hrs = choice("সময়", hours.map { "$it ঘণ্টা" }, Store.i("hours", 5)) { Store.put("hours", it) }
        hrs.visibility = if (Store.b("unlimited", true)) View.GONE else View.VISIBLE
        d.addView(toggle("♾ আনলিমিটেড (Stop না চাপা পর্যন্ত চলবে)", Store.b("unlimited", true)) {
            Store.put("unlimited", it); hrs.visibility = if (it) View.GONE else View.VISIBLE
        })
        d.addView(hrs)
        col.addView(d)

        col.addView(button(if (StreamService.running) "⏹  লাইভ বন্ধ করুন" else "🔴  Go Live", if (StreamService.running) 0xFF374151.toInt() else C.RED) {
            if (StreamService.running) { stopLive(); show(1) } else startLive(if (Store.i("source", 0) == 0) "screen" else "file", null)
        })
    }

    private fun keyCard(col: LinearLayout) {
        val c = card()
        c.addView(label("প্ল্যাটফর্ম ও স্ট্রিম কী", 16f, C.TEXT, true))
        val pi = Store.i("platform", 0)
        val urlEt = edit("সার্ভার URL (Custom RTMP)", Store.s("custom_url"))
        urlEt.visibility = if (pi == 3) View.VISIBLE else View.GONE
        urlEt.addTextChangedListener(watch { Store.put("custom_url", it) })
        c.addView(choice("প্ল্যাটফর্ম", platforms, pi) { Store.put("platform", it); urlEt.visibility = if (it == 3) View.VISIBLE else View.GONE })
        c.addView(urlEt)
        val key = edit("Stream Key", Store.s("key"), pwd = true)
        key.addTextChangedListener(watch { Store.put("key", it.trim()) })
        c.addView(key)
        col.addView(c)
    }

    private fun channelCard(col: LinearLayout) {
        val c = card()
        c.addView(label("📺 YouTube চ্যানেল", 16f, C.TEXT, true))
        val list = Yt.accounts(); val act = Yt.active()
        if (list.isEmpty()) c.addView(label("এখনো কোনো চ্যানেল লগইন করা নেই। নিচের বাটনে চাপুন।", 12f, C.SUB).apply { setPadding(0, dp(6), 0, dp(6)) })
        else c.addView(label("লাইভ হবে যে চ্যানেলে (ট্যাপ করে বদলান):", 12f, C.SUB).apply { setPadding(0, dp(4), 0, dp(2)) })
        list.forEach { a ->
            val on = act?.id == a.id
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setOnClickListener { Yt.select(a.id); show(1) }
                addView(label((if (on) "✅ " else "⚪ ") + a.title, 15f, if (on) C.TEXT else C.SUB, on),
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(TextView(context).apply {
                    text = "🗑"; textSize = 20f; setPadding(dp(12), dp(10), dp(12), dp(10))
                    setOnClickListener { Yt.remove(a.id); show(1) }
                })
            }
            c.addView(row)
        }
        c.addView(button("➕  চ্যানেল লগইন / নতুন চ্যানেল যোগ", C.BLUE) { addChannel() })
        c.addView(label("প্রথমবার: সেটিংস ট্যাবে 'YouTube API সেটআপ' এ Client ID ও Secret দিন।", 11f, C.SUB))
        col.addView(c)
    }

    /** Google Device-flow লগইন: কোড দেখায়, ইউজার Google পেজে চ্যানেল বেছে Allow করলে অ্যাপে চ্যানেল সেভ হয়। */
    private fun addChannel() {
        val cid = Store.s("g_client_id").trim(); val cs = Store.s("g_client_secret").trim()
        if (cid.isEmpty() || cs.isEmpty()) {
            Toast.makeText(this, "আগে Client ID ও Client secret দিন (সেটিংস ট্যাব)", Toast.LENGTH_LONG).show(); show(4); return
        }
        val cancel = AtomicBoolean(false)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(4)) }
        val msg = label("কোড তৈরি হচ্ছে…", 14f, C.TEXT)
        val code = label("", 32f, C.RED, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)) }
        box.addView(msg); box.addView(code)
        val dlg = AlertDialog.Builder(this).setTitle("YouTube চ্যানেল লগইন").setView(box)
            .setCancelable(false).setNegativeButton("বাতিল") { _, _ -> cancel.set(true) }.create()
        dlg.show()
        Thread {
            try {
                val dc = Yt.deviceStart(cid)
                runOnUiThread {
                    code.text = dc.userCode
                    msg.text = "১) কোড কপি হয়েছে, Google পেজ খুলছে\n২) কোডটি দিন → যে চ্যানেলে লাইভ করবেন সেই অ্যাকাউন্ট/চ্যানেল বাছুন → Allow\n৩) তারপর এই অ্যাপে ফিরে আসুন — নিজে নিজেই লগইন হয়ে যাবে।"
                    try { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", dc.userCode)) } catch (_: Exception) {}
                    openUrl(dc.url)
                }
                val acc = Yt.devicePoll(cid, cs, dc, cancel)
                runOnUiThread {
                    try { dlg.dismiss() } catch (_: Exception) {}
                    Toast.makeText(this, "✅ লগইন সফল: ${acc.title}", Toast.LENGTH_LONG).show(); show(1)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    try { dlg.dismiss() } catch (_: Exception) {}
                    if (!cancel.get()) Toast.makeText(this, "লগইন ব্যর্থ: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ================= VIDEOS =================
    private fun videoDir() = File(filesDir, "videos").apply { mkdirs() }

    private fun videos(col: LinearLayout) {
        col.addView(label("আপনার ভিডিও লাইব্রেরি", 22f, C.TEXT, true))
        col.addView(label("MP4 আপলোড করুন, তারপর ভিডিও বেছে 'এই ভিডিও দিয়ে লাইভ' চাপুন।", 12f, C.SUB).apply { setPadding(0, dp(4), 0, dp(10)) })
        val files = videoDir().listFiles()?.sortedBy { it.name } ?: emptyList()
        val used = files.sumOf { it.length() } / (1024 * 1024)
        col.addView(button("⬆  নতুন ভিডিও আপলোড", C.BLUE) { pickLauncher.launch(arrayOf("video/mp4", "video/*")) })
        col.addView(label("মোট ব্যবহার: $used MB", 12f, C.SUB))
        if (files.isEmpty()) col.addView(label("\nএখনো কোনো ভিডিও নেই", 15f, C.SUB).apply { gravity = Gravity.CENTER })
        files.forEach { f ->
            val c = card().apply { setPadding(dp(14), dp(12), dp(14), dp(12)) }
            val sel = Store.s("sel_video") == f.absolutePath
            c.addView(label((if (sel) "✅ " else "🎞 ") + f.name, 14f, C.TEXT, true))
            c.addView(label("${f.length() / (1024 * 1024)} MB", 12f, C.SUB))
            c.addView(button("▶  এই ভিডিও দিয়ে লাইভ", C.RED) {
                Store.put("sel_video", f.absolutePath); Store.put("source", 1); startLive("file", null)
            })
            c.addView(button("এটি বাছাই করুন (লাইভ ট্যাবে গিয়ে সেটআপ)", 0xFF374151.toInt()) {
                Store.put("sel_video", f.absolutePath); Store.put("source", 1); show(1)
            })
            c.addView(button("🗑 মুছুন", 0xFF7F1D1D.toInt()) { f.delete(); if (sel) Store.put("sel_video", ""); show(2) })
            col.addView(c)
        }
    }

    private fun importVideo(uri: Uri) {
        Toast.makeText(this, "ভিডিও কপি হচ্ছে…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                var name = "video_${System.currentTimeMillis()}.mp4"
                contentResolver.query(uri, null, null, null, null)?.use { cur ->
                    val idx = cur.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && cur.moveToFirst()) name = cur.getString(idx).replace("/", "_")
                }
                val out = File(videoDir(), name)
                contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread { Store.put("sel_video", out.absolutePath); Toast.makeText(this, "আপলোড সম্পূর্ণ", Toast.LENGTH_SHORT).show(); if (tab == 2) show(2) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "আপলোড ব্যর্থ: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    // ================= GAME =================
    private fun game(col: LinearLayout) {
        col.addView(label("গেম খেলে লাইভ", 22f, C.TEXT, true))
        col.addView(label("গেম বেছে নিন → 'লাইভ শুরু ও গেম চালু' চাপুন। স্ক্রিন ক্যাপচারের অনুমতি দিলে লাইভ শুরু হয়ে গেম খুলবে। সেটিংস (কোয়ালিটি, অডিও, সময়) 'লাইভ' ট্যাব থেকে আসবে।", 12f, C.SUB).apply { setPadding(0, dp(4), 0, dp(10)) })
        statusCard(col)
        val pkg = Store.s("game_pkg")
        val c = card()
        c.addView(label("নির্বাচিত গেম: " + (if (pkg.isEmpty()) "কিছু নেই" else appLabel(pkg)), 15f, C.TEXT, true))
        c.addView(button("🎮  গেম / অ্যাপ বাছাই করুন", C.BLUE) { pickGame() })
        c.addView(button("🔴  লাইভ শুরু ও গেম চালু", C.RED) {
            if (Store.s("game_pkg").isEmpty()) Toast.makeText(this, "আগে গেম বাছাই করুন", Toast.LENGTH_SHORT).show()
            else if (StreamService.running) Toast.makeText(this, "লাইভ আগেই চলছে", Toast.LENGTH_SHORT).show()
            else startLive("screen", Store.s("game_pkg"))
        })
        c.addView(button("⏹  লাইভ বন্ধ করুন", 0xFF374151.toInt()) { stopLive() })
        col.addView(c)
        col.addView(label("টিপ: গেমের সাউন্ড স্ট্রিমে নিতে অডিও = 'ফোনের সাউন্ড' রাখুন। কিছু গেম ইন্টারনাল অডিও ক্যাপচার ব্লক করে।", 12f, C.SUB))
    }

    private fun appLabel(pkg: String) = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun pickGame() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0)
            .map { Pair(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }.sortedBy { it.first.lowercase() }
        AlertDialog.Builder(this).setTitle("গেম বাছাই করুন")
            .setItems(apps.map { it.first }.toTypedArray()) { _, i -> Store.put("game_pkg", apps[i].second); show(3) }.show()
    }

    // ================= SETTINGS =================
    private fun settings(col: LinearLayout) {
        col.addView(label("সেটিংস", 22f, C.TEXT, true))
        val a = card()
        a.addView(label("অ্যাকাউন্ট: ${Store.s("current_user")}", 15f, C.TEXT, true))
        if (Store.isAdmin()) {
            a.addView(label("অ্যাডমিন প্যানেল — নতুন ইউজার তৈরি করুন (যাকে অ্যাপ দেবেন)", 12f, C.SUB))
            val nid = edit("নতুন ইউজার আইডি"); val npw = edit("পাসওয়ার্ড")
            a.addView(nid); a.addView(npw)
            a.addView(button("➕ ইউজার যোগ করুন", C.BLUE) {
                val i = nid.text.toString().trim(); val p = npw.text.toString()
                if (i.isEmpty() || p.isEmpty() || i.contains("\t") || p.contains("\t")) { Toast.makeText(this, "আইডি ও পাসওয়ার্ড দিন", Toast.LENGTH_SHORT).show(); return@button }
                val l = Store.users().filter { it.first != i }.toMutableList(); l.add(Pair(i, p)); Store.saveUsers(l)
                Toast.makeText(this, "ইউজার যোগ হয়েছে", Toast.LENGTH_SHORT).show(); show(4)
            })
            val users = Store.users()
            users.forEach { u ->
                a.addView(LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(label("👤 ${u.first}  /  ${u.second}", 13f, C.TEXT), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    addView(TextView(context).apply {
                        text = "🗑"; textSize = 20f; setPadding(dp(12), dp(8), dp(12), dp(8))
                        setOnClickListener { Store.saveUsers(Store.users().filter { x -> x.first != u.first }); show(4) }
                    })
                })
            }
            a.addView(label("অ্যাডমিন আইডি/পাসওয়ার্ড বদলান", 12f, C.SUB).apply { setPadding(0, dp(10), 0, 0) })
            val aid = edit("অ্যাডমিন আইডি", Store.adminId()); val apw = edit("অ্যাডমিন পাসওয়ার্ড", Store.adminPass())
            a.addView(aid); a.addView(apw)
            a.addView(button("সেভ করুন", 0xFF374151.toInt()) {
                val i = aid.text.toString().trim(); val p = apw.text.toString()
                if (i.isNotEmpty() && p.isNotEmpty()) { Store.put("admin_id", i); Store.put("admin_pass", p); Store.put("current_user", i); Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show() }
            })
        }
        a.addView(button("🚪 লগআউট", 0xFF7F1D1D.toInt()) {
            if (StreamService.running) Toast.makeText(this, "লাইভ চলছে — লগআউট করলেও লাইভ চলবে", Toast.LENGTH_SHORT).show()
            Store.put("logged_in", false); startActivity(Intent(this, LoginActivity::class.java)); finish()
        })
        col.addView(a)

        val g = card()
        g.addView(label("🔗 YouTube API সেটআপ (চ্যানেল লগইনের জন্য, একবারই)", 16f, C.TEXT, true))
        g.addView(label("১) console.cloud.google.com এ নতুন প্রজেক্ট খুলুন\n২) APIs & Services → Library → 'YouTube Data API v3' → Enable\n৩) OAuth consent screen → External → নিজের Gmail 'Test users' এ দিন (পরে 'Publish app' চাপুন, নইলে ৭ দিন পর আবার লগইন লাগবে)\n৪) Credentials → Create credentials → OAuth client ID → Application type: 'TVs and Limited Input devices'\n৫) যে Client ID ও Client secret পাবেন নিচে পেস্ট করুন", 12f, C.SUB).apply { setPadding(0, dp(6), 0, dp(6)) })
        val cidEt = edit("Client ID", Store.s("g_client_id")); cidEt.addTextChangedListener(watch { Store.put("g_client_id", it.trim()) })
        val csEt = edit("Client secret", Store.s("g_client_secret"), pwd = true); csEt.addTextChangedListener(watch { Store.put("g_client_secret", it.trim()) })
        g.addView(cidEt); g.addView(csEt)
        g.addView(button("🌐 Google Cloud Console খুলুন", 0xFF374151.toInt()) { openUrl("https://console.cloud.google.com/apis/credentials") })
        g.addView(button("📺 YouTube চ্যানেল লগইন করুন", C.RED) { addChannel() })
        col.addView(g)

        val b = card()
        b.addView(label("২৪ ঘণ্টা+ লাইভের জন্য জরুরি", 16f, C.TEXT, true))
        b.addView(label("ব্যাটারি অপ্টিমাইজেশন বন্ধ না করলে ফোন স্ট্রিম কেটে দিতে পারে।", 12f, C.SUB))
        b.addView(button("🔋 ব্যাটারি অপ্টিমাইজেশন বন্ধ করুন", C.BLUE) { batteryOpt() })
        b.addView(button("▶ YouTube Studio / Live খুলুন", 0xFF374151.toInt()) { openUrl("https://studio.youtube.com") })
        col.addView(b)
        col.addView(label("JISNEX Live 24/7 • v1.1", 11f, C.SUB).apply { gravity = Gravity.CENTER })
    }

    private fun batteryOpt() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) { Toast.makeText(this, "আগেই বন্ধ করা আছে ✅", Toast.LENGTH_SHORT).show(); return }
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
    }

    private fun openUrl(u: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Exception) {} }

    // ================= START / STOP =================
    private fun buildUrl(): String {
        val p = Store.i("platform", 0)
        var base = if (p == 3) Store.s("custom_url").trim() else bases[p]
        val key = Store.s("key").trim()
        if (key.isEmpty()) return base
        if (!base.endsWith("/")) base += "/"
        return base + key
    }

    private fun startLive(source: String, game: String?) {
        if (StreamService.running) { Toast.makeText(this, "লাইভ আগেই চলছে", Toast.LENGTH_SHORT).show(); return }
        if (source == "file" && !File(Store.s("sel_video")).exists()) { Toast.makeText(this, "আগে ভিডিও আপলোড করে বাছাই করুন", Toast.LENGTH_LONG).show(); show(2); return }
        if (Store.i("mode", 0) == 0) { startViaChannel(source, game); return }
        if (Store.s("key").isEmpty() && Store.i("platform", 0) != 3) { Toast.makeText(this, "আগে Stream Key দিন (লাইভ ট্যাব)", Toast.LENGTH_LONG).show(); show(1); return }
        val url = buildUrl()
        if (!url.startsWith("rtmp")) { Toast.makeText(this, "সঠিক RTMP URL দিন", Toast.LENGTH_LONG).show(); return }
        beginCapture(source, game, url, "", "")
    }

    /** চ্যানেল মোড: YouTube এ লাইভ তৈরি করে তারপর ক্যাপচার শুরু। */
    private fun startViaChannel(source: String, game: String?) {
        val acc = Yt.active()
        if (acc == null) { Toast.makeText(this, "আগে YouTube চ্যানেল লগইন করুন", Toast.LENGTH_LONG).show(); show(1); return }
        Toast.makeText(this, "YouTube এ লাইভ তৈরি হচ্ছে…", Toast.LENGTH_SHORT).show()
        val privacy = listOf("public", "unlisted", "private")[Store.i("privacy", 0).coerceIn(0, 2)]
        val title = Store.s("title"); val desc = Store.s("desc")
        Thread {
            try {
                val s = Yt.createLive(acc, title, desc, privacy)
                runOnUiThread { beginCapture(source, game, s.url, s.broadcastId, acc.id) }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "YouTube: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun beginCapture(source: String, game: String?, url: String, bid: String, chId: String) {
        pendingGame = game; pendingSource = source; pendingUrl = url; pendingBid = bid; pendingCh = chId
        ensurePerms {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED && source == "screen") {
                discardPending()
                Toast.makeText(this, "মাইক/অডিও অনুমতি লাগবে", Toast.LENGTH_LONG).show()
            } else if (source == "screen") {
                val mp = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projLauncher.launch(mp.createScreenCaptureIntent())
            } else launchService("file", 0, null)
        }
    }

    /** ক্যাপচার শুরু না হলে YouTube এর অব্যবহৃত broadcast মুছে ফেলে। */
    private fun discardPending() {
        val b = pendingBid; val c = pendingCh
        pendingBid = ""; pendingCh = ""
        if (b.isEmpty()) return
        Thread { try { Yt.byId(c)?.let { Yt.discard(it, b) } } catch (_: Throwable) { } }.start()
    }

    private fun ensurePerms(next: () -> Unit) {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) next() else { afterPerm = next; permLauncher.launch(need.toTypedArray()) }
    }

    private fun launchService(mode: String, code: Int, data: Intent?) {
        val o = Store.i("orient", 0); val r = Store.i("res", 2)
        var w = resW[r]; var h = resH[r]
        if (o == 1) { val t = w; w = h; h = t }
        val audio = listOf("internal", "mic", "none")[Store.i("audio", 0)]
        val minutes = if (Store.b("unlimited", true)) 0 else hours[Store.i("hours", 5)] * 60
        val i = Intent(this, StreamService::class.java).setAction(StreamService.ACTION_START)
            .putExtra("mode", mode).putExtra("url", pendingUrl).putExtra("bid", pendingBid).putExtra("chid", pendingCh).putExtra("audio", audio)
            .putExtra("w", w).putExtra("h", h).putExtra("fps", fpsList[Store.i("fps", 1)])
            .putExtra("kbps", resKbps[r]).putExtra("minutes", minutes)
            .putExtra("title", Store.s("title")).putExtra("file", Store.s("sel_video"))
            .putExtra("resultCode", code)
        if (data != null) i.putExtra("data", data)
        ContextCompat.startForegroundService(this, i)
        pendingBid = ""; pendingCh = ""
        Toast.makeText(this, "লাইভ শুরু হচ্ছে…", Toast.LENGTH_SHORT).show()
        val g = pendingGame; pendingGame = null
        if (g != null) ui.postDelayed({
            packageManager.getLaunchIntentForPackage(g)?.let { startActivity(it) }
        }, 2500)
        else ui.postDelayed({ if (tab == 1) show(1) }, 800)
    }

    private fun stopLive() {
        startService(Intent(this, StreamService::class.java).setAction(StreamService.ACTION_STOP))
        Toast.makeText(this, "লাইভ বন্ধ করা হচ্ছে", Toast.LENGTH_SHORT).show()
    }

    private fun watch(f: (String) -> Unit) = object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { f(s?.toString() ?: "") }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
