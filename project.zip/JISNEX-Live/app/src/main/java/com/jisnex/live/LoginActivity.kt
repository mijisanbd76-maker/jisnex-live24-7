package com.jisnex.live

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        if (Store.b("logged_in") && Store.s("current_user").isNotEmpty()) { goMain(); return }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            layoutParams = LinearLayout.LayoutParams(dp(180), dp(180))
        }
        col.addView(logo)
        col.addView(label("JISNEX Live 24/7", 24f, C.TEXT, true))
        col.addView(label("লগইন করে স্ট্রিমিং শুরু করুন", 14f, C.SUB).apply { setPadding(0, dp(4), 0, dp(20)) })
        val id = edit("আইডি (ID)")
        val pw = edit("পাসওয়ার্ড", pwd = true)
        col.addView(id); col.addView(pw)
        col.addView(button("লগইন", C.RED) {
            val i = id.text.toString().trim(); val p = pw.text.toString()
            if (Store.check(i, p)) {
                Store.put("logged_in", true); Store.put("current_user", i); goMain()
            } else Toast.makeText(this, "আইডি বা পাসওয়ার্ড ভুল", Toast.LENGTH_SHORT).show()
        })
        col.addView(label("ডিফল্ট অ্যাডমিন: admin / admin123 (Settings থেকে বদলান)", 11f, C.SUB).apply { setPadding(0, dp(10), 0, 0) })
        setContentView(ScrollView(this).apply {
            setBackgroundColor(C.BG)
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    private fun goMain() { startActivity(Intent(this, MainActivity::class.java)); finish() }
}
