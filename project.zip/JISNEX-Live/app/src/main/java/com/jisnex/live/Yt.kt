package com.jisnex.live

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.atomic.AtomicBoolean

data class Acc(val id: String, val title: String, val rt: String)
class DeviceCode(val deviceCode: String, val userCode: String, val url: String, val expires: Int, val interval: Int)
class LiveSession(val broadcastId: String, val streamId: String, val url: String)
class YtError(msg: String) : Exception(msg)

/** Google OAuth (device flow) + YouTube Live Streaming API. কোনো বাড়তি লাইব্রেরি লাগে না। */
object Yt {
    private const val API = "https://www.googleapis.com/youtube/v3"
    private const val SCOPE = "https://www.googleapis.com/auth/youtube"
    private const val TOKEN_URL = "https://oauth2.googleapis.com/token"

    private var at = ""
    private var atExp = 0L
    private var atFor = ""

    // ---------------- চ্যানেল/অ্যাকাউন্ট সংরক্ষণ ----------------
    fun accounts(): MutableList<Acc> {
        val out = mutableListOf<Acc>()
        try {
            val a = JSONArray(Store.s("yt_accounts", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Acc(o.getString("id"), o.optString("title"), o.getString("rt")))
            }
        } catch (_: Exception) { }
        return out
    }

    private fun save(l: List<Acc>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("rt", it.rt)) }
        Store.put("yt_accounts", a.toString())
    }

    fun active(): Acc? {
        val l = accounts()
        return l.firstOrNull { it.id == Store.s("yt_active") } ?: l.firstOrNull()
    }

    fun byId(id: String): Acc? = accounts().firstOrNull { it.id == id }
    fun select(id: String) { Store.put("yt_active", id) }

    @Synchronized
    fun remove(id: String) {
        save(accounts().filter { it.id != id })
        if (Store.s("yt_active") == id) Store.put("yt_active", "")
        if (atFor == id) { at = ""; atExp = 0L }
    }

    // ---------------- HTTP ----------------
    private class Resp(val code: Int, val json: JSONObject)

    private fun form(vararg p: Pair<String, String>) =
        p.joinToString("&") { URLEncoder.encode(it.first, "UTF-8") + "=" + URLEncoder.encode(it.second, "UTF-8") }

    private fun http(method: String, url: String, body: String? = null, token: String? = null, isForm: Boolean = false): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20000
            c.readTimeout = 30000
            c.setRequestProperty("Accept", "application/json")
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            if (method == "POST" || method == "PUT") {
                c.doOutput = true
                c.setRequestProperty("Content-Type",
                    if (isForm) "application/x-www-form-urlencoded" else "application/json; charset=utf-8")
                c.outputStream.use { it.write((body ?: "").toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            val j = try { if (text.isBlank()) JSONObject() else JSONObject(text) } catch (e: Exception) { JSONObject() }
            return Resp(code, j)
        } finally {
            c.disconnect()
        }
    }

    private fun fail(r: Resp): Nothing {
        val e = r.json.opt("error")
        var reason = ""
        var msg = "HTTP ${r.code}"
        if (e is JSONObject) {
            msg = e.optString("message", msg)
            reason = e.optJSONArray("errors")?.optJSONObject(0)?.optString("reason") ?: ""
        } else if (e is String) {
            msg = r.json.optString("error_description", e)
            reason = e
        }
        val text = when {
            reason == "liveStreamingNotEnabled" || reason == "livePermissionBlocked" ->
                "এই চ্যানেলে লাইভ স্ট্রিমিং চালু নেই। YouTube Studio তে গিয়ে Go Live থেকে চ্যানেল ভেরিফাই করুন (চালু হতে ২৪ ঘণ্টা লাগতে পারে)।"
            reason == "accessNotConfigured" || msg.contains("has not been used") || msg.contains("is disabled") ->
                "Google Cloud এ 'YouTube Data API v3' Enable করা নেই।"
            reason == "quotaExceeded" || reason == "rateLimitExceeded" || reason == "dailyLimitExceeded" ->
                "আজকের YouTube API কোটা শেষ। কাল আবার চেষ্টা করুন।"
            reason == "invalid_grant" -> "লগইনের মেয়াদ শেষ। আবার চ্যানেল লগইন করুন।"
            reason == "invalid_client" || reason == "unauthorized_client" ->
                "Client ID / Client secret ভুল, অথবা ক্লায়েন্ট টাইপ 'TVs and Limited Input devices' নয়।"
            reason == "insufficientPermissions" || reason == "forbidden" && r.code == 403 && msg.contains("scope") ->
                "পর্যাপ্ত অনুমতি নেই। চ্যানেল আবার লগইন করুন।"
            reason == "invalidTransition" -> "লাইভ স্টেট পরিবর্তন করা যায়নি (স্ট্রিম ডেটা এখনো আসেনি)।"
            else -> msg
        }
        throw YtError(text)
    }

    private fun ok(method: String, url: String, body: String?, token: String): JSONObject {
        val r = http(method, url, body, token)
        if (r.code !in 200..299) fail(r)
        return r.json
    }

    // ---------------- Access token ----------------
    @Synchronized
    fun token(acc: Acc): String {
        if (at.isNotEmpty() && atFor == acc.id && System.currentTimeMillis() < atExp - 60_000) return at
        val r = http("POST", TOKEN_URL, form(
            "client_id" to Store.s("g_client_id").trim(),
            "client_secret" to Store.s("g_client_secret").trim(),
            "refresh_token" to acc.rt,
            "grant_type" to "refresh_token"), null, true)
        if (r.code != 200) fail(r)
        at = r.json.getString("access_token")
        atFor = acc.id
        atExp = System.currentTimeMillis() + r.json.optLong("expires_in", 3000L) * 1000L
        return at
    }

    // ---------------- Login (Device flow) ----------------
    fun deviceStart(clientId: String): DeviceCode {
        val r = http("POST", "https://oauth2.googleapis.com/device/code",
            form("client_id" to clientId, "scope" to SCOPE), null, true)
        if (r.code != 200) fail(r)
        val j = r.json
        return DeviceCode(
            j.getString("device_code"), j.getString("user_code"),
            j.optString("verification_url", "https://www.google.com/device"),
            j.optInt("expires_in", 1800), j.optInt("interval", 5))
    }

    @Synchronized
    private fun addAccount(acc: Acc, access: String, expiresSec: Long) {
        val l = accounts().filter { it.id != acc.id }.toMutableList()
        l.add(acc)
        save(l)
        select(acc.id)
        at = access; atFor = acc.id; atExp = System.currentTimeMillis() + expiresSec * 1000L
    }

    /** ইউজার Google পেজে অনুমতি দেওয়া পর্যন্ত অপেক্ষা করে; সফল হলে চ্যানেল সেভ করে। */
    fun devicePoll(clientId: String, secret: String, d: DeviceCode, cancel: AtomicBoolean): Acc {
        var wait = d.interval.coerceAtLeast(3)
        val end = System.currentTimeMillis() + d.expires * 1000L
        while (System.currentTimeMillis() < end) {
            var s = 0
            while (s < wait * 10) {
                if (cancel.get()) throw YtError("বাতিল করা হয়েছে")
                Thread.sleep(100); s++
            }
            val r = http("POST", TOKEN_URL, form(
                "client_id" to clientId, "client_secret" to secret,
                "device_code" to d.deviceCode,
                "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"), null, true)
            if (r.code == 200) {
                val access = r.json.getString("access_token")
                val rt = r.json.optString("refresh_token")
                if (rt.isEmpty()) throw YtError("রিফ্রেশ টোকেন পাওয়া যায়নি, আবার চেষ্টা করুন")
                val ch = ok("GET", "$API/channels?part=snippet&mine=true", null, access)
                val items = ch.optJSONArray("items")
                if (items == null || items.length() == 0)
                    throw YtError("এই Google অ্যাকাউন্টে কোনো YouTube চ্যানেল নেই। সঠিক চ্যানেল/ব্র্যান্ড অ্যাকাউন্ট বাছুন।")
                val first = items.getJSONObject(0)
                val acc = Acc(first.getString("id"), first.getJSONObject("snippet").optString("title", "Channel"), rt)
                addAccount(acc, access, r.json.optLong("expires_in", 3000L))
                return acc
            }
            when (r.json.optString("error")) {
                "authorization_pending" -> { }
                "slow_down" -> wait += 5
                "access_denied" -> throw YtError("আপনি অনুমতি দেননি (Access denied)")
                "expired_token" -> throw YtError("কোডের মেয়াদ শেষ, আবার চেষ্টা করুন")
                else -> fail(r)
            }
        }
        throw YtError("সময় শেষ, আবার চেষ্টা করুন")
    }

    // ---------------- Live ----------------
    private fun iso(ms: Long): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(ms))

    /** নতুন stream + broadcast বানিয়ে বাইন্ড করে; RTMP URL (স্ট্রিম কী সহ) ফেরত দেয়। */
    fun createLive(acc: Acc, title: String, desc: String, privacy: String): LiveSession {
        val t = token(acc)
        val name = title.trim().ifEmpty { "JISNEX Live" }.take(95)

        val st = ok("POST", "$API/liveStreams?part=snippet,cdn,contentDetails", JSONObject()
            .put("snippet", JSONObject().put("title", "$name (stream)"))
            .put("cdn", JSONObject().put("frameRate", "variable").put("ingestionType", "rtmp").put("resolution", "variable"))
            .put("contentDetails", JSONObject().put("isReusable", false))
            .toString(), t)
        val sid = st.getString("id")
        val info = st.getJSONObject("cdn").getJSONObject("ingestionInfo")
        val url = info.getString("ingestionAddress").trimEnd('/') + "/" + info.getString("streamName")

        val br = ok("POST", "$API/liveBroadcasts?part=snippet,status,contentDetails", JSONObject()
            .put("snippet", JSONObject()
                .put("title", name)
                .put("description", desc.take(4900))
                .put("scheduledStartTime", iso(System.currentTimeMillis() + 15_000)))
            .put("status", JSONObject().put("privacyStatus", privacy).put("selfDeclaredMadeForKids", false))
            .put("contentDetails", JSONObject()
                .put("enableAutoStart", true)
                .put("enableAutoStop", false)
                .put("enableDvr", true)
                .put("recordFromStart", true)
                .put("monitorStream", JSONObject().put("enableMonitorStream", false)))
            .toString(), t)
        val bid = br.getString("id")

        try {
            ok("POST", "$API/liveBroadcasts/bind?id=$bid&part=id,contentDetails&streamId=$sid", null, t)
        } catch (e: Exception) {
            try { ok("DELETE", "$API/liveBroadcasts?id=$bid", null, t) } catch (_: Exception) { }
            throw e
        }
        return LiveSession(bid, sid, url)
    }

    fun lifecycle(acc: Acc, bid: String): String {
        val j = ok("GET", "$API/liveBroadcasts?part=status&id=$bid", null, token(acc))
        val a = j.optJSONArray("items") ?: return ""
        return if (a.length() > 0) a.getJSONObject(0).getJSONObject("status").optString("lifeCycleStatus") else ""
    }

    fun transition(acc: Acc, bid: String, status: String) {
        ok("POST", "$API/liveBroadcasts/transition?broadcastStatus=$status&id=$bid&part=status", null, token(acc))
    }

    /** লাইভ শুরু না হওয়া broadcast মুছে ফেলে (অনুমতি/ক্যাপচার বাতিল হলে)। */
    fun discard(acc: Acc, bid: String) {
        val lc = lifecycle(acc, bid)
        if (lc == "created" || lc == "ready") ok("DELETE", "$API/liveBroadcasts?id=$bid", null, token(acc))
    }

    /** স্ট্রিম বন্ধ হলে YouTube এ লাইভ শেষ করে (ভিডিও আর্কাইভ হয়)। */
    fun finish(acc: Acc, bid: String) {
        val lc = lifecycle(acc, bid)
        when (lc) {
            "complete", "revoked" -> { }
            "created", "ready" -> ok("DELETE", "$API/liveBroadcasts?id=$bid", null, token(acc))
            else -> transition(acc, bid, "complete")
        }
    }
}
