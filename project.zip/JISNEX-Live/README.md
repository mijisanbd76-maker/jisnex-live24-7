# JISNEX Live 24/7 — বিল্ড গাইড (v1.1)

## GitHub দিয়ে APK বানানো
1. github.com এ নতুন repository খুলুন (যেমন: jisnex-live)।
2. এই জিপ unzip করে **সব ফাইল ও `.github` ফোল্ডারসহ** repo তে আপলোড করুন।
3. repo → **Actions** ট্যাব → "Build JISNEX Live APK" → Run workflow।
4. ৫–১০ মিনিট পর **Artifacts → JISNEX-Live-APK** ডাউনলোড করে `app-debug.apk` ইনস্টল করুন।

বিল্ড ফেইল করলে Actions এর লাল লগের শেষ ১৫–২০ লাইন কপি করে আমাকে দিন।

## অ্যাপে প্রথম লগইন
ID: admin / পাসওয়ার্ড: admin123 → Settings থেকে বদলান।

## পদ্ধতি ১: চ্যানেল লগইন করে লাইভ (নতুন)
একবারের সেটআপ (Settings ট্যাব → YouTube API সেটআপ):
1. console.cloud.google.com → নতুন প্রজেক্ট
2. APIs & Services → Library → **YouTube Data API v3** → Enable
3. OAuth consent screen → External → নিজের Gmail **Test users** এ দিন। পরে **Publish app** চাপুন (না চাপলে ৭ দিন পর আবার লগইন লাগবে)
4. Credentials → Create credentials → OAuth client ID → Application type: **TVs and Limited Input devices**
5. Client ID ও Client secret অ্যাপের Settings এ পেস্ট করুন

এরপর: লাইভ ট্যাব → মোড "চ্যানেল লগইন" → "চ্যানেল লগইন / যোগ" → Google পেজে কোড দিয়ে চ্যানেল বেছে Allow → অ্যাপে ফিরুন → টাইটেল দিয়ে **Go Live**।
অ্যাপ নিজেই YouTube এ লাইভ তৈরি করে, স্ট্রিম পাঠায়, LIVE করে, আর Stop চাপলে লাইভ শেষ করে।
একাধিক চ্যানেল যোগ করে ট্যাপ করে বদলানো যায়।

নোট: চ্যানেলে লাইভ স্ট্রিমিং আগে থেকে চালু (ভেরিফাইড) থাকতে হবে।

## পদ্ধতি ২: Stream Key দিয়ে
লাইভ ট্যাব → মোড "Stream Key" → YouTube Studio → Go Live → Stream key কপি করে পেস্ট → Go Live।
